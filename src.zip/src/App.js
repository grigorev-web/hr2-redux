import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import AppContainer from "./components/layout/AppContainer";
import MainMenu from "./components/menus/MainMenu";
import AdminPage from "./components/pages/admin";

import Operator from "./components/pages/operator";
import Recruter from "./components/pages/recruter";

function App() {
  return (
    <BrowserRouter>
      <AppContainer>
        <MainMenu />

        <Routes>
          <Route path="/" element={<Operator />} />
          <Route path="operator" element={<Operator />} />
          <Route path="recruter" element={<Recruter />} />
          <Route path="admin" element={<AdminPage />} />
        </Routes>

      </AppContainer>
    </BrowserRouter>
  );
}

export default App;
