const initialState = {
    candidates:[],
}


export default initialState;