const reducer = (state, action) => {
    switch (action.type) {
      case "CHANGE_SORT":
        return {...state,
                filter: {
                  ...state.filter,
                  sort: action.payload
                }
              }
        break;
  
      
      default:
        return state;
        break;
    }
  };
  
  export default reducer;