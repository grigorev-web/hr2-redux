import TableCandidatesLayout from "../../../layout/TableCandidatesLayout";
import TableCandidatesHead from "./TableCandidatesHead";
import TableCandidatesRow from "./TableCandidatesRow";

const TableCandidates = () => {
  return (
    <TableCandidatesLayout>
      <table className="align-middle mb-0 table table-borderless table-striped table-hover">
        <TableCandidatesHead />
        <tbody>
          <TableCandidatesRow />
          <TableCandidatesRow />
          <TableCandidatesRow />
          <TableCandidatesRow />
        </tbody>
      </table>
    </TableCandidatesLayout>
  );
};

export default TableCandidates;
