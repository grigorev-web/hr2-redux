const CellActions = () => {
  return (
    <td>
      <button type="button" className="btn btn-primary btn-sm">
        Details
      </button>
    </td>
  );
};

export default CellActions;
