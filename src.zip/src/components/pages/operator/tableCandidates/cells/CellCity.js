

const CellCity = () =>{
    return <td>Madrid</td>
}

export default CellCity;