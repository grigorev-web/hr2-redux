import avatar from "../../../../../images/avatar.jpg";

const CellName = () => {
  return (
    <td>
      <div className="widget-content p-0">
        <div className="widget-content-wrapper">
          <div className="widget-content-left mr-3">
            <div className="widget-content-left">
              <img
                width="40"
                className="rounded-circle"
                src={avatar}
                alt="Avatar"
              />
            </div>
          </div>
          <div className="widget-content-left flex2">
            <div className="widget-heading">Пётр Иванов</div>
            <div className="widget-subheading opacity-7">Веб разработчик</div>
          </div>
        </div>
      </div>
    </td>
  );
};

export default CellName;
