import StatusBadge from "../../../../basic/Badge/StatusBadge";


const CellStatus = () =>{
    return <td><StatusBadge status={2} /></td>
}

export default CellStatus;