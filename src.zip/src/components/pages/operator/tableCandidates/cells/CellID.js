

const CellID = () =>{
    return <td>#345</td>
}

export default CellID;