



const TableCandidatesHead = () => {
  return (
    <thead>
      <tr>
        <th className="text-center">#</th>
        <th>ФИО</th>
        <th className="text-center">Город</th>
        <th className="text-center">Статус</th>
        <th className="text-center">Действия</th>
      </tr>
    </thead>
  );
};

export default TableCandidatesHead;