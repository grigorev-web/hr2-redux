import CellActions from "./cells/CellActions";
import CellCity from "./cells/CellCity";
import CellID from "./cells/CellID";
import CellName from "./cells/CellName";
import CellStatus from "./cells/CellStatus";



const TableCandidatesRow = () => {
    return <tr>
        <CellID/>
        <CellName/>
        <CellCity/>
        <CellStatus/>
        <CellActions/>
    </tr>
}

export default TableCandidatesRow;