import PageLayout from "../../layout/PageLayout";
import TableCandidates from "./tableCandidates/TableCandidates";




const Operator = () => {
  return (
    <PageLayout>
      <TableCandidates/>
    </PageLayout>
  );
};


export default Operator;
