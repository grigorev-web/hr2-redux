import PageLayout from "../../layout/PageLayout";
import RecruterDesk from "./desk/RecruterDesk";





const Recruter = () => {
  return (
    <PageLayout>
      <RecruterDesk/>
    </PageLayout>
  );
};


export default Recruter;
