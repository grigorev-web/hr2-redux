import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { useState, useEffect } from "react";
import avatar from '../../../../images/avatar.jpg'
// fake data generator
const getItems = (count, offset = 0) =>
  Array.from({ length: count }, (v, k) => k).map((k) => ({
    id: `item-${k + offset}`,
    //content: `item ${k + offset}`,
    content: <div className="widget-content p-0">
    <div className="widget-content-wrapper">
      <div className="widget-content-left mr-3">
        <div className="widget-content-left">
          <img
            width="40"
            className="rounded-circle"
            src={avatar}
            alt="Avatar"
          />
        </div>
      </div>
      <div className="widget-content-left flex2">
        <div className="widget-heading">Пётр Иванов</div>
        <div className="widget-subheading opacity-7">{`Веб разработчик ${k + offset}`}</div>
      </div>
    </div>
  </div>
  }));

const RecruterDesk = () => {
  const [state, setState] = useState({items:[], selected: []});

  useEffect(
    () =>
      setState({
        items: getItems(10),
        selected: getItems(5, 10),
      }),
    []
  );

  function onDragEnd() {
    console.log("drag end");
  }

  function onDragStart() {
    console.log("drag start");
  };

  const getListStyle = (isDraggingOver) => ({
    background: isDraggingOver ? "lightblue" : "white",
    padding: grid,
    width: 250,
    margin: '6px',
  });

  // a little function to help us with reordering the result
  const reorder = (list, startIndex, endIndex) => {
    const result = Array.from(list);
    const [removed] = result.splice(startIndex, 1);
    result.splice(endIndex, 0, removed);

    return result;
  };

  /**
   * Moves an item from one list to another list.
   */
  const move = (source, destination, droppableSource, droppableDestination) => {
    const sourceClone = Array.from(source);
    const destClone = Array.from(destination);
    const [removed] = sourceClone.splice(droppableSource.index, 1);

    destClone.splice(droppableDestination.index, 0, removed);

    const result = {};
    result[droppableSource.droppableId] = sourceClone;
    result[droppableDestination.droppableId] = destClone;

    return result;
  };

  const getItemStyle = (isDragging, draggableStyle) => ({
    // some basic styles to make the items look a bit nicer
    userSelect: "none",
    padding: grid * 2,
    margin: `0 0 ${grid}px 0`,

    // change background colour if dragging
    background: isDragging ? "lightgreen" : "white",
    border: '1px solid #dfd6d6',

    // styles we need to apply on draggables
    ...draggableStyle,
  });

  const grid = 8;

  return (
      <div className="row">
    <DragDropContext onDragStart={onDragStart} onDragEnd={onDragEnd}>
      <Droppable droppableId="droppable" >
        {(provided, snapshot) => (
          <div className="card"
            ref={provided.innerRef}
            style={getListStyle(snapshot.isDraggingOver)}
          >
              <div className="card-header mb-3">Приглашены</div>
            {state.items.map((item, index) => (
              <Draggable key={item.id} draggableId={item.id} index={index}>
                {(provided, snapshot) => (
                  <div className="card"
                    ref={provided.innerRef}
                    {...provided.draggableProps}
                    {...provided.dragHandleProps}
                    style={getItemStyle(
                      snapshot.isDragging,
                      provided.draggableProps.style
                    )}
                  >
                    {item.content}
                  </div>
                )}
              </Draggable>
            ))}
            {provided.placeholder}
          </div>
        )}
      </Droppable>
      <Droppable droppableId="droppable2">
        {(provided, snapshot) => (
          <div className="card"
            ref={provided.innerRef}
            style={getListStyle(snapshot.isDraggingOver)}
          >
              <div className="card-header mb-3">Перенесено</div>
            {state.selected.map((item, index) => (
              <Draggable key={item.id} draggableId={item.id} index={index}>
                {(provided, snapshot) => (
                  <div className="card"
                    ref={provided.innerRef}
                    {...provided.draggableProps}
                    {...provided.dragHandleProps}
                    style={getItemStyle(
                      snapshot.isDragging,
                      provided.draggableProps.style
                    )}
                  >
                    {item.content}
                  </div>
                )}
              </Draggable>
            ))}
            {provided.placeholder}
          </div>
        )}
      </Droppable>

      
    </DragDropContext>
    </div>
  );
};

export default RecruterDesk;
