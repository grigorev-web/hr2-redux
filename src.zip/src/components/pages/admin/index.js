import PageLayout from "../../layout/PageLayout";

const AdminPage = () => {
  return (
    <PageLayout>
      <h1>Admin page</h1>
    </PageLayout>
  );
};

export default AdminPage;
