

const StatusBadge = ({status}) => {
    return <div className="badge badge-warning">{`badge ${status}`}</div>
}

export default StatusBadge;