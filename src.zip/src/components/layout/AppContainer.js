

const AppContainer = ({children}) => {
    return (
        <div className="app-container app-theme-white">
          <div className="app-main">
           {children}
          </div>
        </div>
      );
}

export default AppContainer;