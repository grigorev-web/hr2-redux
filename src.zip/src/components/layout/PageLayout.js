const PageLayout = ({ children }) => {
  return (
    <div className="app-main__outer">
      <div className="app-main__inner">{children}</div>
    </div>
  );
};

export default PageLayout;
