

const TableCandidatesLayout = ({ children }) => {
  return (
    <div className="row">
      <div className="col-md-12">
        <div className="main-card mb-3 card">
          <div className="card-header">
            Список кандидатов
            <div className="btn-actions-pane-right">
              <div role="group" className="btn-group-sm btn-group">
                <button className="active btn btn-info">Прош. неделя</button>
                <button className="btn btn-info">За месяц</button>
              </div>
            </div>
          </div>

          <div className="table-responsive">
              {children}
          </div>

          <div className="d-block text-center card-footer">
           
          </div>
        </div>
      </div>
    </div>
  );
};


export default TableCandidatesLayout;